"""
Problem Set 01 – Chest X-Ray Classification (Pneumonia vs Normal)
CNN model built with TensorFlow / Keras

Dataset layout expected:
    chest_xray/
        train/
            NORMAL/
            PNEUMONIA/
        val/
            NORMAL/
            PNEUMONIA/
        test/
            NORMAL/
            PNEUMONIA/

Author : Student Solution
"""

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)

import tensorflow as tf
from tensorflow.keras import layers, models, regularizers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import (
    EarlyStopping,
    ModelCheckpoint,
    ReduceLROnPlateau,
)
from tensorflow.keras.optimizers import Adam

# ─────────────────────────────────────────
# 1. CONFIGURATION
# ─────────────────────────────────────────
DATA_DIR   = "chest_xray"          # change if dataset lives elsewhere
IMG_SIZE   = (150, 150)
BATCH_SIZE = 32
EPOCHS     = 30
SEED       = 42
MODEL_PATH = "best_cnn_model.keras"

tf.random.set_seed(SEED)
np.random.seed(SEED)


# ─────────────────────────────────────────
# 2. DATA LOADING & AUGMENTATION
# ─────────────────────────────────────────
def build_generators(data_dir: str):
    """Return train / val / test generators with augmentation on train."""

    train_datagen = ImageDataGenerator(
        rescale=1.0 / 255,
        rotation_range=15,
        width_shift_range=0.10,
        height_shift_range=0.10,
        shear_range=0.10,
        zoom_range=0.10,
        horizontal_flip=True,
        fill_mode="nearest",
    )

    # Validation & test: only rescale – no augmentation
    eval_datagen = ImageDataGenerator(rescale=1.0 / 255)

    train_gen = train_datagen.flow_from_directory(
        os.path.join(data_dir, "train"),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        seed=SEED,
        shuffle=True,
    )

    val_gen = eval_datagen.flow_from_directory(
        os.path.join(data_dir, "val"),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        shuffle=False,
    )

    test_gen = eval_datagen.flow_from_directory(
        os.path.join(data_dir, "test"),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        shuffle=False,
    )

    return train_gen, val_gen, test_gen


# ─────────────────────────────────────────
# 3. MODEL ARCHITECTURE
# ─────────────────────────────────────────
def build_cnn_model(input_shape: tuple) -> tf.keras.Model:
    """
    Custom CNN with 4 convolutional blocks followed by dense layers.
    BatchNormalization + Dropout are used to regularise and prevent over-fitting.
    """
    model = models.Sequential(name="ChestXRay_CNN")

    # ── Block 1 ──────────────────────────
    model.add(layers.Conv2D(32, (3, 3), activation="relu",
                            padding="same", input_shape=input_shape))
    model.add(layers.BatchNormalization())
    model.add(layers.Conv2D(32, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(layers.Dropout(0.25))

    # ── Block 2 ──────────────────────────
    model.add(layers.Conv2D(64, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.Conv2D(64, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(layers.Dropout(0.25))

    # ── Block 3 ──────────────────────────
    model.add(layers.Conv2D(128, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.Conv2D(128, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(layers.Dropout(0.30))

    # ── Block 4 ──────────────────────────
    model.add(layers.Conv2D(256, (3, 3), activation="relu", padding="same"))
    model.add(layers.BatchNormalization())
    model.add(layers.MaxPooling2D(pool_size=(2, 2)))
    model.add(layers.Dropout(0.30))

    # ── Dense Head ───────────────────────
    model.add(layers.GlobalAveragePooling2D())
    model.add(layers.Dense(256, activation="relu",
                           kernel_regularizer=regularizers.l2(1e-4)))
    model.add(layers.BatchNormalization())
    model.add(layers.Dropout(0.50))
    model.add(layers.Dense(1, activation="sigmoid"))  # binary output

    return model


# ─────────────────────────────────────────
# 4. CLASS-WEIGHT CALCULATION (handles imbalance)
# ─────────────────────────────────────────
def compute_class_weights(generator) -> dict:
    counter = np.bincount(generator.classes)
    total   = counter.sum()
    weights = {i: total / (len(counter) * c) for i, c in enumerate(counter)}
    print(f"Class weights → {weights}")
    return weights


# ─────────────────────────────────────────
# 5. TRAINING
# ─────────────────────────────────────────
def train_model(model, train_gen, val_gen, class_weights):
    model.compile(
        optimizer=Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.AUC(name="auc"),
                 tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall")],
    )
    model.summary()

    callbacks = [
        EarlyStopping(monitor="val_auc", patience=6,
                      restore_best_weights=True, mode="max", verbose=1),
        ModelCheckpoint(MODEL_PATH, monitor="val_auc",
                        save_best_only=True, mode="max", verbose=1),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                          patience=3, min_lr=1e-6, verbose=1),
    ]

    history = model.fit(
        train_gen,
        epochs=EPOCHS,
        validation_data=val_gen,
        class_weight=class_weights,
        callbacks=callbacks,
        verbose=1,
    )
    return history


# ─────────────────────────────────────────
# 6. EVALUATION
# ─────────────────────────────────────────
def evaluate_model(model, test_gen):
    print("\n──────────────  TEST SET EVALUATION  ──────────────")
    results = model.evaluate(test_gen, verbose=1)
    metric_names = model.metrics_names
    for name, val in zip(metric_names, results):
        print(f"  {name:12s}: {val:.4f}")

    # Predictions
    y_prob = model.predict(test_gen, verbose=0).ravel()
    y_pred = (y_prob >= 0.5).astype(int)
    y_true = test_gen.classes

    print("\nClassification Report:")
    print(classification_report(y_true, y_pred,
          target_names=list(test_gen.class_indices.keys())))

    auc = roc_auc_score(y_true, y_prob)
    print(f"ROC-AUC Score : {auc:.4f}")

    return y_true, y_pred, y_prob


# ─────────────────────────────────────────
# 7. VISUALISATIONS
# ─────────────────────────────────────────
def plot_training_history(history):
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.suptitle("Training History – Chest X-Ray CNN", fontsize=14, fontweight="bold")

    metrics = [("accuracy", "Accuracy"), ("loss", "Loss"), ("auc", "AUC")]
    for ax, (metric, label) in zip(axes, metrics):
        ax.plot(history.history[metric],        label=f"Train {label}", linewidth=2)
        ax.plot(history.history[f"val_{metric}"],label=f"Val {label}",   linewidth=2, linestyle="--")
        ax.set_title(label)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(label)
        ax.legend()
        ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig("training_history.png", dpi=150, bbox_inches="tight")
    plt.show()
    print("Saved: training_history.png")


def plot_confusion_matrix(y_true, y_pred, class_names):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set_title("Confusion Matrix – Test Set", fontweight="bold")
    ax.set_ylabel("True Label")
    ax.set_xlabel("Predicted Label")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.show()
    print("Saved: confusion_matrix.png")


def plot_roc_curve(y_true, y_prob):
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    auc = roc_auc_score(y_true, y_prob)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="steelblue", linewidth=2, label=f"AUC = {auc:.4f}")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1)
    ax.set_title("ROC Curve – Test Set", fontweight="bold")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("roc_curve.png", dpi=150, bbox_inches="tight")
    plt.show()
    print("Saved: roc_curve.png")


def visualise_predictions(model, test_gen, num_images: int = 12):
    """Display a grid of test images with true vs predicted labels."""
    class_names = {v: k for k, v in test_gen.class_indices.items()}
    images, labels = next(test_gen)
    preds = (model.predict(images, verbose=0).ravel() >= 0.5).astype(int)

    cols = 4
    rows = num_images // cols
    fig, axes = plt.subplots(rows, cols, figsize=(14, rows * 3.5))
    fig.suptitle("Sample Predictions (Green = Correct, Red = Wrong)",
                 fontsize=13, fontweight="bold")

    for idx, ax in enumerate(axes.flat):
        if idx >= num_images:
            ax.axis("off")
            continue
        img   = images[idx]
        truth = int(labels[idx])
        pred  = int(preds[idx])
        color = "green" if truth == pred else "red"
        ax.imshow(img, cmap="gray")
        ax.set_title(
            f"True: {class_names[truth]}\nPred: {class_names[pred]}",
            color=color, fontsize=9,
        )
        ax.axis("off")

    plt.tight_layout()
    plt.savefig("sample_predictions.png", dpi=150, bbox_inches="tight")
    plt.show()
    print("Saved: sample_predictions.png")


# ─────────────────────────────────────────
# 8. MAIN
# ─────────────────────────────────────────
def main():
    print("=" * 55)
    print("  Chest X-Ray Classification  |  CNN Solution")
    print("=" * 55)

    # Generators
    train_gen, val_gen, test_gen = build_generators(DATA_DIR)
    print(f"\nClass indices : {train_gen.class_indices}")
    print(f"Train samples : {train_gen.samples}")
    print(f"Val samples   : {val_gen.samples}")
    print(f"Test samples  : {test_gen.samples}")

    # Class weights (dataset is imbalanced: more Pneumonia than Normal)
    class_weights = compute_class_weights(train_gen)

    # Model
    input_shape = IMG_SIZE + (3,)
    model = build_cnn_model(input_shape)

    # Train
    history = train_model(model, train_gen, val_gen, class_weights)

    # Evaluate
    y_true, y_pred, y_prob = evaluate_model(model, test_gen)
    class_names = list(test_gen.class_indices.keys())

    # Plots
    plot_training_history(history)
    plot_confusion_matrix(y_true, y_pred, class_names)
    plot_roc_curve(y_true, y_prob)
    visualise_predictions(model, test_gen)

    print("\nDone. Model saved to:", MODEL_PATH)


if __name__ == "__main__":
    main()
