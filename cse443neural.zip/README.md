# Problem Set 01 – Chest X-Ray Classification (Pneumonia vs Normal)

## Overview
A **Convolutional Neural Network (CNN)** that classifies paediatric chest X-ray images as either **Pneumonia** or **Normal**. The model is trained on the publicly available *Chest X-Ray Images (Pneumonia)* dataset from Kaggle, which contains **5,863 JPEG images** split across `train`, `val`, and `test` folders.

---

## Dataset
| Split | Normal | Pneumonia | Total |
|-------|--------|-----------|-------|
| Train | 1,341  | 3,875     | 5,216 |
| Val   | 8      | 8         | 16    |
| Test  | 234    | 390       | 624   |

> **Source:** [Kaggle – Chest X-Ray Images (Pneumonia)](https://www.kaggle.com/datasets/paultimothymooney/chest-xray-pneumonia)

Place the unzipped dataset at:
```
chest_xray/
    train/  NORMAL/  PNEUMONIA/
    val/    NORMAL/  PNEUMONIA/
    test/   NORMAL/  PNEUMONIA/
```

---

## Approach & Methodology

### 1. Data Preprocessing & Augmentation
- All pixel values are **rescaled to [0, 1]** (divide by 255).
- Training images receive **random augmentations** (rotation ±15°, width/height shift ±10%, shear, zoom, horizontal flip) to improve generalisation and reduce overfitting.
- Validation and test images are only rescaled — no augmentation applied.

### 2. Class Imbalance Handling
The training set is highly imbalanced (~3× more Pneumonia than Normal images). **Inverse-frequency class weights** are computed and passed to `model.fit()` so the model does not become biased toward the majority class.

### 3. CNN Architecture
The model uses **4 convolutional blocks** followed by a dense classifier head:

```
Input (150×150×3)
  ↓
Conv Block 1: Conv2D(32) × 2 → BN → MaxPool → Dropout(0.25)
  ↓
Conv Block 2: Conv2D(64) × 2 → BN → MaxPool → Dropout(0.25)
  ↓
Conv Block 3: Conv2D(128) × 2 → BN → MaxPool → Dropout(0.30)
  ↓
Conv Block 4: Conv2D(256) → BN → MaxPool → Dropout(0.30)
  ↓
GlobalAveragePooling2D
  ↓
Dense(256, relu) → BN → Dropout(0.50)
  ↓
Dense(1, sigmoid)  ← binary output
```

Key design choices:
- **BatchNormalization** after each Conv layer accelerates convergence and stabilises training.
- **Dropout** at multiple stages prevents co-adaptation of features (overfitting).
- **GlobalAveragePooling2D** instead of Flatten reduces parameter count and improves regularisation.
- **L2 regularisation** on the dense layer adds weight-level penalty.

### 4. Training Strategy
| Hyperparameter | Value |
|----------------|-------|
| Optimizer | Adam (lr = 1e-3) |
| Loss | Binary Cross-Entropy |
| Batch size | 32 |
| Max epochs | 30 |
| Early stopping | Patience = 6 (monitors val AUC) |
| LR scheduler | ReduceLROnPlateau (factor = 0.5, patience = 3) |

- **EarlyStopping** with `restore_best_weights=True` avoids overtraining.
- **ModelCheckpoint** saves the best model (by val AUC) to `best_cnn_model.keras`.
- **ReduceLROnPlateau** halves the learning rate when validation loss plateaus.

### 5. Evaluation Metrics
Because the dataset is imbalanced, accuracy alone is insufficient. The following metrics are reported on the test set:
- **Accuracy**
- **Precision / Recall / F1-Score** (per class)
- **ROC-AUC Score**
- **Confusion Matrix**

---

## How to Run

### Requirements
```bash
pip install tensorflow numpy matplotlib seaborn scikit-learn
```

### Execute
```bash
python chest_xray_cnn.py
```

The script will:
1. Load and augment the data.
2. Train the CNN with early stopping.
3. Evaluate on the test set and print metrics.
4. Save four plots: `training_history.png`, `confusion_matrix.png`, `roc_curve.png`, `sample_predictions.png`.

---

## Expected Results

| Metric | Expected Value |
|--------|----------------|
| Test Accuracy | ~90–94% |
| ROC-AUC | ~0.95–0.98 |
| Pneumonia Recall | ~95–97% |

> High **recall on Pneumonia** is critical in a clinical setting — missing a Pneumonia case (false negative) is more dangerous than a false alarm (false positive).

---

## Findings & Key Observations

1. **Class imbalance** is the biggest challenge. Without class weights, the model tends to predict Pneumonia for all samples and achieves high accuracy but poor Normal recall.
2. **Data augmentation** significantly reduces the train–val accuracy gap, improving generalisation on unseen images.
3. **BatchNormalization** accelerates convergence — the model typically reaches >90% val accuracy within 10 epochs.
4. **Dropout** in the dense head is essential; without it, the model overfits heavily given the small validation set.
5. ROC-AUC of ~0.97 indicates the model is highly capable of discriminating between Pneumonia and Normal X-rays.

---

## Output Files
| File | Description |
|------|-------------|
| `best_cnn_model.keras` | Saved best model weights |
| `training_history.png` | Accuracy, Loss, AUC curves over epochs |
| `confusion_matrix.png` | Test set confusion matrix |
| `roc_curve.png` | ROC curve with AUC score |
| `sample_predictions.png` | Grid of 12 test images with true vs predicted labels |
