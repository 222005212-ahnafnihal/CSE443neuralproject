# Machine Learning Assignment

## Repository Structure

```
├── problem_set_01/          # CNN – Chest X-Ray Classification
│   ├── chest_xray_cnn.py
│   └── README.md
│
├── problem_set_02/          # Logistic Regression – Bank Term Deposit
│   ├── bank_logistic_regression.py
│   ├── bank-full.csv
│   └── README.md
│
└── README.md                ← you are here
```

## Problem Set 01 – Chest X-Ray CNN
Classifies paediatric chest X-ray images into **Pneumonia** or **Normal** using a custom 4-block CNN built with TensorFlow/Keras.  
→ See [`problem_set_01/README.md`](problem_set_01/README.md)

## Problem Set 02 – Bank Marketing Logistic Regression
Predicts whether a customer will subscribe to a **term deposit** using Logistic Regression on 45,211 customer records.  
→ See [`problem_set_02/README.md`](problem_set_02/README.md)

## Requirements
```bash
pip install tensorflow numpy pandas scikit-learn matplotlib seaborn
```
