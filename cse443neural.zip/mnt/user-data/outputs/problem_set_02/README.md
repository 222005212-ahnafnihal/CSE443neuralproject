# Problem Set 02 – Bank Marketing: Term Deposit Subscription Prediction

## Overview
A **Logistic Regression** classifier that predicts whether a bank customer will subscribe to a **term deposit** based on their demographic and banking behaviour data. The model is trained on the *Bank Marketing Data Set* (`bank-full.csv`) containing **45,211 customer records** with 17 attributes.

---

## Dataset Description
| Attribute | Type | Description |
|-----------|------|-------------|
| age | Numeric | Customer age |
| job | Categorical | Type of employment |
| marital | Categorical | Marital status |
| education | Ordinal | Education level |
| default | Binary | Has credit in default? |
| balance | Numeric | Average yearly account balance (€) |
| housing | Binary | Has housing loan? |
| loan | Binary | Has personal loan? |
| contact | Categorical | Contact communication type |
| day | Numeric | Last contact day of month |
| month | Categorical | Last contact month |
| duration | Numeric | Last contact duration (seconds) |
| campaign | Numeric | Number of contacts in current campaign |
| pdays | Numeric | Days since last contact (-1 = never) |
| previous | Numeric | Contacts before this campaign |
| poutcome | Categorical | Outcome of previous campaign |
| **y** | **Target** | **Subscribed to term deposit? (yes/no)** |

---

## Class Distribution
| Class | Count | Percentage |
|-------|-------|------------|
| No (did not subscribe) | 39,922 | 88.3% |
| Yes (subscribed) | 5,289 | 11.7% |

> The dataset is **highly imbalanced** — only ~12% of customers subscribed. This is handled via `class_weight='balanced'` in the model.

---

## Approach & Methodology

### 1. Exploratory Data Analysis (EDA)
- Checked for missing values → **zero missing values** in the dataset.
- Analysed the distribution of numeric features (age, balance, duration) segmented by target class.
- Examined subscription rates across job categories, marital status, and education levels.
- Computed a correlation matrix for all numeric features.

### 2. Feature Engineering & Preprocessing
| Step | Detail |
|------|--------|
| Target encoding | `yes → 1`, `no → 0` |
| Education | Ordinal encoding: `unknown=0, primary=1, secondary=2, tertiary=3` |
| Other categoricals | Label encoding (job, marital, contact, month, poutcome, etc.) |
| Log-transform balance | `log1p(clip(balance, 0))` — corrects right-skewed distribution |
| Interaction feature | `duration × campaign` — captures combined call intensity signal |
| `contacted_before` | Binary flag: `pdays != -1` → 1, else 0 |
| Drop columns | Dropped raw `balance` (replaced) and `pdays` (captured by flag) |

### 3. Train/Test Split
- **80/20 stratified split** → 36,168 train · 9,043 test
- Stratification ensures both splits maintain the same class ratio (~11.7%).

### 4. Model: Logistic Regression Pipeline
```
StandardScaler  →  LogisticRegression
```
Key hyperparameters:
| Parameter | Value | Reason |
|-----------|-------|--------|
| `C` | 1.0 | Default regularisation; prevents overfitting |
| `class_weight` | `'balanced'` | Accounts for 88:12 class imbalance |
| `solver` | `'lbfgs'` | Efficient for medium-size datasets |
| `max_iter` | 1000 | Ensures convergence |

**StandardScaler** is used inside a `Pipeline` to prevent data leakage — the scaler is fit only on training data.

### 5. Model Evaluation Strategy
- **5-fold Stratified Cross-Validation** on training set.
- Final evaluation on held-out test set.
- Metrics: Accuracy, Precision, Recall, F1 Score, ROC-AUC.

---

## Results

### Cross-Validation (5-Fold, Training Set)
| Metric | Mean | ± Std |
|--------|------|-------|
| Accuracy | 0.8245 | ±0.0051 |
| ROC-AUC | 0.8893 | ±0.0035 |
| F1 Score | 0.5142 | ±0.0096 |

### Test Set Performance
| Metric | Score |
|--------|-------|
| **Accuracy** | **0.8269** |
| **Precision** | **0.3836** |
| **Recall** | **0.7892** |
| **F1 Score** | **0.5162** |
| **ROC-AUC** | **0.8891** |

### Per-Class Report
```
              precision    recall  f1-score   support
    No  (0)      0.97      0.83      0.89      7985
    Yes (1)      0.38      0.79      0.52      1058
    accuracy                         0.83      9043
```

---

## Findings & Key Observations

1. **Class imbalance is the dominant challenge.** Using `class_weight='balanced'` dramatically improves recall on the minority class (Yes) from ~30% to ~79%, at the cost of some false positives.

2. **`duration` is the most predictive feature.** The length of the last phone call strongly correlates with subscription — a longer conversation indicates genuine customer interest. However, this feature would not be available before a call is made, so in a real deployment scenario, models trained without `duration` should also be tested.

3. **`poutcome` (previous campaign outcome)** is highly informative. Customers who subscribed in a previous campaign are much more likely to subscribe again.

4. **`log_balance`** improves model performance over raw balance because the distribution is right-skewed with significant outliers.

5. **ROC-AUC of ~0.889** indicates the model has strong discriminatory power between subscribers and non-subscribers.

6. **High recall (78.9%) for the Yes class** is the right optimisation target for a bank — it is better to call a few extra customers (false positives) than to miss genuine prospects (false negatives).

---

## How to Run

### Requirements
```bash
pip install pandas numpy scikit-learn matplotlib seaborn
```

### Execute
```bash
python bank_logistic_regression.py
```

The script will:
1. Load and display EDA statistics.
2. Preprocess features and split the data.
3. Run 5-fold cross-validation and print scores.
4. Train on the full training set and evaluate on the test set.
5. Save all plots to `./plots/`.

---

## Output Files
| File | Description |
|------|-------------|
| `plots/target_distribution.png` | Bar chart of Yes vs No counts |
| `plots/age_distribution.png` | Age histogram by target class |
| `plots/subscription_by_job.png` | Subscription rate per job category |
| `plots/balance_distribution.png` | Balance distribution by target class |
| `plots/correlation_heatmap.png` | Correlation matrix for numeric features |
| `plots/confusion_matrix.png` | Test set confusion matrix |
| `plots/roc_curve.png` | ROC curve with AUC score |
| `plots/feature_importance.png` | Top 15 features by |coefficient| |
| `plots/probability_distribution.png` | Predicted probability distributions |
