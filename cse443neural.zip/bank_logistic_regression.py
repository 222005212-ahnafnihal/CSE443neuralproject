"""
Problem Set 02 – Bank Marketing: Term Deposit Subscription Prediction
Logistic Regression model

Dataset: bank-full.csv (Bank Marketing Data Set)
Target : y → 'yes' / 'no' (subscribed to term deposit)

Author : Student Solution
"""

import warnings
warnings.filterwarnings("ignore")

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
    confusion_matrix,
    classification_report,
)
from sklearn.pipeline import Pipeline

# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────
DATA_PATH = os.path.join(os.path.dirname(__file__), "bank-full.csv")
SEED      = 42
TEST_SIZE = 0.20


# ─────────────────────────────────────────
# 1. LOAD DATA
# ─────────────────────────────────────────
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, sep=";")
    print(f"Dataset loaded  →  {df.shape[0]:,} rows  ×  {df.shape[1]} columns")
    return df


# ─────────────────────────────────────────
# 2. EXPLORATORY DATA ANALYSIS (EDA)
# ─────────────────────────────────────────
def run_eda(df: pd.DataFrame) -> None:
    print("\n─────────  EDA  ─────────")
    print(df.dtypes)
    print("\nMissing values:\n", df.isnull().sum())
    print("\nTarget distribution:\n", df["y"].value_counts())
    print(f"\nClass balance  → yes: {(df['y']=='yes').mean()*100:.1f}%  |  "
          f"no: {(df['y']=='no').mean()*100:.1f}%")
    print("\nNumeric summary:\n", df.describe().T.to_string())


def plot_eda(df: pd.DataFrame) -> None:
    os.makedirs("plots", exist_ok=True)

    # ── Target distribution ──────────────
    fig, ax = plt.subplots(figsize=(6, 4))
    counts = df["y"].value_counts()
    ax.bar(counts.index, counts.values,
           color=["#2196F3", "#FF7043"], edgecolor="white", width=0.5)
    for i, (label, val) in enumerate(counts.items()):
        ax.text(i, val + 100, f"{val:,}", ha="center", fontweight="bold")
    ax.set_title("Target Variable Distribution", fontweight="bold", fontsize=13)
    ax.set_xlabel("Subscribed to Term Deposit")
    ax.set_ylabel("Count")
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/target_distribution.png", dpi=150)
    plt.close()

    # ── Age distribution by target ───────
    fig, ax = plt.subplots(figsize=(8, 4))
    for label, grp in df.groupby("y"):
        ax.hist(grp["age"], bins=30, alpha=0.6, label=label, edgecolor="white")
    ax.set_title("Age Distribution by Subscription", fontweight="bold", fontsize=13)
    ax.set_xlabel("Age")
    ax.set_ylabel("Frequency")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/age_distribution.png", dpi=150)
    plt.close()

    # ── Subscription rate by job ─────────
    job_rate = (df.groupby("job")["y"]
                  .apply(lambda s: (s == "yes").mean() * 100)
                  .sort_values(ascending=False))
    fig, ax = plt.subplots(figsize=(10, 5))
    job_rate.plot(kind="bar", ax=ax, color="steelblue", edgecolor="white")
    ax.set_title("Subscription Rate by Job Category", fontweight="bold", fontsize=13)
    ax.set_xlabel("Job")
    ax.set_ylabel("Subscription Rate (%)")
    ax.tick_params(axis="x", rotation=45)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/subscription_by_job.png", dpi=150)
    plt.close()

    # ── Balance distribution ─────────────
    fig, ax = plt.subplots(figsize=(8, 4))
    df_clip = df.copy()
    df_clip["balance"] = df_clip["balance"].clip(-1000, 10000)
    for label, grp in df_clip.groupby("y"):
        ax.hist(grp["balance"], bins=50, alpha=0.6, label=label, edgecolor="white")
    ax.set_title("Account Balance Distribution by Subscription", fontweight="bold", fontsize=13)
    ax.set_xlabel("Balance (clipped to [-1000, 10000])")
    ax.set_ylabel("Frequency")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/balance_distribution.png", dpi=150)
    plt.close()

    # ── Correlation heatmap (numeric) ────
    numeric_df = df.select_dtypes(include=[np.number])
    fig, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(numeric_df.corr(), annot=True, fmt=".2f", cmap="coolwarm",
                center=0, linewidths=0.5, ax=ax)
    ax.set_title("Correlation Matrix – Numeric Features", fontweight="bold", fontsize=13)
    plt.tight_layout()
    plt.savefig("plots/correlation_heatmap.png", dpi=150)
    plt.close()

    print("EDA plots saved to ./plots/")


# ─────────────────────────────────────────
# 3. FEATURE ENGINEERING & PREPROCESSING
# ─────────────────────────────────────────
def preprocess(df: pd.DataFrame):
    """
    Steps:
      1. Encode target (yes=1, no=0)
      2. Ordinal-encode 'education'
      3. Label-encode remaining categoricals
      4. Feature engineering: log-transform balance, interaction term
      5. Drop highly correlated / low-value columns
    """
    df = df.copy()

    # ── Target encoding ──────────────────
    df["y"] = (df["y"] == "yes").astype(int)

    # ── Ordinal encoding for education ───
    edu_order = {"unknown": 0, "primary": 1, "secondary": 2, "tertiary": 3}
    df["education"] = df["education"].map(edu_order)

    # ── Label-encode remaining object cols ─
    cat_cols = df.select_dtypes(include="object").columns.tolist()
    le = LabelEncoder()
    for col in cat_cols:
        df[col] = le.fit_transform(df[col].astype(str))

    # ── Feature engineering ──────────────
    # Log-transform balance (right-skewed); shift to avoid log(0) or log(negative)
    df["log_balance"] = np.log1p(df["balance"].clip(lower=0))

    # Interaction: duration × campaign (more calls + longer last call → more likely)
    df["duration_x_campaign"] = df["duration"] * df["campaign"]

    # contacted_before: binary flag (pdays == -1 means never contacted)
    df["contacted_before"] = (df["pdays"] != -1).astype(int)

    # Drop raw balance (replaced by log version) and pdays (captured in flag + value)
    df.drop(columns=["balance", "pdays"], inplace=True)

    print(f"\nAfter preprocessing: {df.shape[1]} features (including target)")
    return df


def split_data(df: pd.DataFrame):
    X = df.drop(columns=["y"])
    y = df["y"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=SEED, stratify=y
    )
    print(f"Train : {X_train.shape[0]:,}  |  Test : {X_test.shape[0]:,}")
    print(f"Train positive rate : {y_train.mean()*100:.1f}%  |  "
          f"Test positive rate  : {y_test.mean()*100:.1f}%")
    return X_train, X_test, y_train, y_test


# ─────────────────────────────────────────
# 4. MODEL – LOGISTIC REGRESSION PIPELINE
# ─────────────────────────────────────────
def build_pipeline(C: float = 1.0) -> Pipeline:
    """
    StandardScaler → LogisticRegression
    class_weight='balanced' handles class imbalance automatically.
    solver='lbfgs' is efficient for medium datasets; max_iter=1000 ensures convergence.
    """
    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("lr", LogisticRegression(
            C=C,
            class_weight="balanced",
            solver="lbfgs",
            max_iter=1000,
            random_state=SEED,
        )),
    ])
    return pipeline


# ─────────────────────────────────────────
# 5. CROSS-VALIDATION
# ─────────────────────────────────────────
def cross_validate(pipeline, X_train, y_train) -> None:
    print("\n─────────  5-Fold Stratified CV  ─────────")
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    for metric in ["accuracy", "roc_auc", "f1"]:
        scores = cross_val_score(pipeline, X_train, y_train,
                                 cv=skf, scoring=metric, n_jobs=-1)
        print(f"  {metric:12s} : {scores.mean():.4f}  ± {scores.std():.4f}")


# ─────────────────────────────────────────
# 6. EVALUATION
# ─────────────────────────────────────────
def evaluate(pipeline, X_test, y_test) -> tuple:
    y_pred = pipeline.predict(X_test)
    y_prob = pipeline.predict_proba(X_test)[:, 1]

    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec  = recall_score(y_test, y_pred)
    f1   = f1_score(y_test, y_pred)
    auc  = roc_auc_score(y_test, y_prob)

    print("\n─────────  TEST SET RESULTS  ─────────")
    print(f"  Accuracy  : {acc:.4f}")
    print(f"  Precision : {prec:.4f}")
    print(f"  Recall    : {rec:.4f}")
    print(f"  F1 Score  : {f1:.4f}")
    print(f"  ROC-AUC   : {auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred,
                                 target_names=["No (0)", "Yes (1)"]))

    return y_test, y_pred, y_prob


# ─────────────────────────────────────────
# 7. VISUALISATIONS
# ─────────────────────────────────────────
def plot_confusion_matrix(y_test, y_pred) -> None:
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No", "Yes"],
                yticklabels=["No", "Yes"], ax=ax,
                annot_kws={"size": 14, "weight": "bold"})
    ax.set_title("Confusion Matrix – Logistic Regression", fontweight="bold", fontsize=13)
    ax.set_xlabel("Predicted Label", fontsize=11)
    ax.set_ylabel("True Label", fontsize=11)
    plt.tight_layout()
    plt.savefig("plots/confusion_matrix.png", dpi=150)
    plt.close()
    print("Saved: plots/confusion_matrix.png")


def plot_roc_curve(y_test, y_prob) -> None:
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    auc = roc_auc_score(y_test, y_prob)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="steelblue", linewidth=2.5,
            label=f"Logistic Regression (AUC = {auc:.4f})")
    ax.fill_between(fpr, tpr, alpha=0.10, color="steelblue")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="Random Classifier")
    ax.set_title("ROC Curve", fontweight="bold", fontsize=13)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/roc_curve.png", dpi=150)
    plt.close()
    print("Saved: plots/roc_curve.png")


def plot_feature_importance(pipeline, feature_names: list) -> None:
    """Plot top 15 features by absolute logistic regression coefficient."""
    coef = pipeline.named_steps["lr"].coef_[0]
    importance = pd.Series(np.abs(coef), index=feature_names).sort_values(ascending=False)
    top15 = importance.head(15)

    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ["#2196F3" if c > 0 else "#FF7043"
              for c in pipeline.named_steps["lr"].coef_[0][
                  [list(feature_names).index(f) for f in top15.index]]]
    top15.plot(kind="barh", ax=ax, color=colors[::-1], edgecolor="white")
    ax.invert_yaxis()
    ax.set_title("Top 15 Feature Importances (|Coefficient|)", fontweight="bold", fontsize=13)
    ax.set_xlabel("|Logistic Regression Coefficient|")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/feature_importance.png", dpi=150)
    plt.close()
    print("Saved: plots/feature_importance.png")


def plot_probability_distribution(y_test, y_prob) -> None:
    fig, ax = plt.subplots(figsize=(8, 4))
    for label, name in [(0, "No (did not subscribe)"), (1, "Yes (subscribed)")]:
        mask = (y_test == label)
        ax.hist(y_prob[mask], bins=40, alpha=0.65, label=name, edgecolor="white")
    ax.axvline(0.5, color="red", linewidth=1.5, linestyle="--", label="Default threshold (0.5)")
    ax.set_title("Predicted Probability Distribution by True Class",
                 fontweight="bold", fontsize=13)
    ax.set_xlabel("Predicted Probability of Subscription")
    ax.set_ylabel("Count")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig("plots/probability_distribution.png", dpi=150)
    plt.close()
    print("Saved: plots/probability_distribution.png")


# ─────────────────────────────────────────
# 8. MAIN
# ─────────────────────────────────────────
def main():
    print("=" * 55)
    print("  Bank Marketing – Term Deposit Prediction")
    print("  Logistic Regression Solution")
    print("=" * 55)

    df = load_data(DATA_PATH)
    run_eda(df)
    plot_eda(df)

    df_processed = preprocess(df)
    X_train, X_test, y_train, y_test = split_data(df_processed)

    pipeline = build_pipeline(C=1.0)
    cross_validate(pipeline, X_train, y_train)

    pipeline.fit(X_train, y_train)
    y_test_arr, y_pred, y_prob = evaluate(pipeline, X_test, y_test)

    feature_names = X_train.columns.tolist()
    plot_confusion_matrix(y_test_arr, y_pred)
    plot_roc_curve(y_test_arr, y_prob)
    plot_feature_importance(pipeline, feature_names)
    plot_probability_distribution(np.array(y_test_arr), y_prob)

    print("\nAll done. Plots saved in ./plots/")


if __name__ == "__main__":
    main()
